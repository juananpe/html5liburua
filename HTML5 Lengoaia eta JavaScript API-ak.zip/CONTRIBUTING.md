# LaTeX ekarpenak nola egin

Ekarpenak asko eskertzen ditugu. Berez horregatik erabaki genuen liburua irekitzea, besteak beste.

Libururako **LaTeX**-en ekarpenak egin nahi badituzu, hau da modu erraz bat:

0. GitHubeko proiektuaren fork bat egin
<img width="300" alt="image" src="https://user-images.githubusercontent.com/1078305/203990309-028c7082-5001-4ec8-ad53-ec4b20709cd8.png">


1. http://Overleaf.com webgunean sartu

3. New Project / Import from GitHub aukeratu
<img width="300" alt="image" src="https://user-images.githubusercontent.com/1078305/203990381-116acc34-ae9d-4489-8509-2519dc192348.png">

3. Liburuaren repo-a aukeratu 
<img width="624" alt="image" src="https://user-images.githubusercontent.com/1078305/203990585-4bd4b8ef-c152-4687-853e-d720fc575d12.png">

4) Overleaf-en menuan, TeX Live version 2021 aukeratu
<img width="300" alt="image" src="https://user-images.githubusercontent.com/1078305/203990635-0cc93ec1-87fb-4d58-84fd-653007ccdd2f.png">

5) latex/main.text fitxategian editatu nahi EZ dituzun kapituluak komentatu
<img width="600" alt="image" src="https://user-images.githubusercontent.com/1078305/203990685-0b75cbd8-4746-4784-9400-3e929eec2b1f.png">

6) Zure ekarpena egin

7) Recompile botoian sakatu
<img width="600" alt="image" src="https://user-images.githubusercontent.com/1078305/203990744-09957a82-ffec-4d57-86d1-f239042be9b0.png">

Listo! LaTeXen egindakoa GitHub-era igo (issue berri bat sortu, edo hobe Pull Request bat sortu) Ez badakizu nola egin, galdetu eta gure laguntza jasoko duzu.

